package com.alibaba.dubbo.common.extensionloader.ext6_inject.impl;

import com.alibaba.dubbo.common.extensionloader.ext6_inject.Dao;

public class DaoImpl implements Dao {
    public void update() {

    }
}
